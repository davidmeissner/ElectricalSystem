Simscape Probes 

Owner: Tom Egel
Last update: 24-April-2014
Latest Tested Release: R2014a

Overview:
The Simscape Probes provide quick access to the internal (through and across) physical variables used by the Simscape-based Physical Modeling tools.

Install Instructions:
1. Add SimscapeProbes directory to your MATLAB path
2. Run sl_refresh_customizations or restart MATLAB
3. run ssc_Probes.m
4. See Help block for usage details
5. See Archive folder for compatibility with older versions of MATLAB
6. See Examples folder to see how Probes are used.