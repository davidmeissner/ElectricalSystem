% Copyright 2012 The MathWorks(TM), Inc.

%{


% PARAMETERS FOR HYDRAULIC CYLINDER
RO = 0.1;
t = 0.005;
h = 2.5;
lic = -1.1;
rho = 1000;

%
APist = pi*(RO - 2*t)*(RO - 2*t);
ROO = RO;
RIO = RO - t;
ROI = RO-t;
RII = RO- 2*t;
h_seg = h/2;

ro = ROO;
ri = RIO;
h = h_seg;
rho = rho;
rot_oc = [0 0 165];

mass_OC = rho*pi*(ro*ro-ri*ri)*h;
inertia_OC = mass_OC*([(3*ro*ro + h*h) 0 0;0 6*ro*ro 0;0 0 (3*ro*ro + h*h)]-[(3*ri*ri + h*h) 0 0;0 6*ri*ri 0;0 0 (3*ri*ri + h*h)])/12;

ro = ROI;
ri = RII;
h = h_seg;
rho = rho;
rot_ic = [0 0 0];

mass_IC = rho*pi*(ro*ro-ri*ri)*h;
inertia_IC = mass_IC*([(3*ro*ro + h*h) 0 0;0 6*ro*ro 0;0 0 (3*ro*ro + h*h)]-[(3*ri*ri + h*h) 0 0;0 6*ri*ri 0;0 0 (3*ri*ri + h*h)])/12;

a = 0.1;
b = 2;
c = 0.05;
rho = 1000;
theta = 180;

mass_Link = rho*a*b*c;
inertia_Link = rho*a*b*c*[(b^2+c^2) 0 0; 0 (a^2+c^2) 0; 0 0 (a^2+b^2)]/12;

Actuator_Attach_Pt = [0 -0.2 0];
Actuator_Wing_Pt = [-0.5 0 0];

Outer_Cyl_Axis = Actuator_Wing_Pt - Actuator_Attach_Pt;
Actuator_Angle = -10;
Outer_Cyl_CS2 = Outer_Cyl_Axis*Outer_Cylinder_Length;

Cylinder_Overlap = 0.05;
Signal_Times = linspace(0,0.5,11);
Signal_Values = [0 1 1 0 0 -1 -1 0 0 0 0];


Airfoil_Length = 1;
Airfoil_Thickness_1 = 0.25;
Airfoil_Thickness_2 = 0.2;
Airfoil_Offset_1=0.15;
Airfoil_Offset_2=-0.13;
Airfoil_Nose_Length = 0.10;

Wind_Offset = 0.7;

Ka = 1*1e-1;
Kb = 2500;

Ka_Final = 0.1791;
Kb_Final = 343.75;

%}

% GEOMETRY 2G
AEH_Param.Airfoil.Nose_Length = 0.4;
AEH_Param.Airfoil.Nose_Height = 0.15;
AEH_Param.Airfoil.Tail_Length = 0.1;
AEH_Param.Airfoil.Tail_Height = 0.05;
AEH_Param.Airfoil.Length = 1;
AEH_Param.Airfoil.Front_Ellipse.Cut_Angle = 40;
AEH_Param.Airfoil.Rear_Ellipse.Cut_Angle = 30;

AEH_Param.Airfoil.Front_Ellipse = Extr_Data_Ellipse(AEH_Param.Airfoil.Nose_Length,AEH_Param.Airfoil.Nose_Height,90-AEH_Param.Airfoil.Front_Ellipse.Cut_Angle,270+AEH_Param.Airfoil.Front_Ellipse.Cut_Angle,1);
AEH_Param.Airfoil.Rear_EllipseA = Extr_Data_Ellipse(AEH_Param.Airfoil.Tail_Length,AEH_Param.Airfoil.Tail_Height,270+AEH_Param.Airfoil.Rear_Ellipse.Cut_Angle,359,1);
AEH_Param.Airfoil.Rear_EllipseB = Extr_Data_Ellipse(AEH_Param.Airfoil.Tail_Length,AEH_Param.Airfoil.Tail_Height,0,90-AEH_Param.Airfoil.Rear_Ellipse.Cut_Angle,1);
AEH_Param.Airfoil.Rear_Ellipse = [AEH_Param.Airfoil.Rear_EllipseA; AEH_Param.Airfoil.Rear_EllipseB];
AEH_Param.Airfoil.Ellipse_Offset = AEH_Param.Airfoil.Length-AEH_Param.Airfoil.Nose_Length-AEH_Param.Airfoil.Tail_Height;
AEH_Param.Airfoil.Rear_Ellipse = AEH_Param.Airfoil.Rear_Ellipse+[ones(size(AEH_Param.Airfoil.Rear_Ellipse,1),1)*AEH_Param.Airfoil.Ellipse_Offset zeros(size(AEH_Param.Airfoil.Rear_Ellipse,1),1)];
AEH_Param.Airfoil.ExtrData = [AEH_Param.Airfoil.Front_Ellipse;AEH_Param.Airfoil.Rear_Ellipse];

AEH_Param.Airfoil.CG_Offset = [-0.1 0 0];
AEH_Param.Airfoil.Actuator_Attach_Pt = [-0.3 -0.1 0];
AEH_Param.Airfoil.Wing_Attach_Pt = [-0.3 0 0];
AEH_Param.Airfoil.Wing_Damping = 10;  % deg/s

AEH_Param.Airfoil.Mass = 0.1;  % kg
AEH_Param.Airfoil.Inertia = [66.7084 0.2084 66.8334];  % kg*m^2

AEH_Param.Actuator.Cylinder.Length = 0.35;
AEH_Param.Actuator.Cylinder.Radius = 0.035;
AEH_Param.Actuator.Initial_Overlap = AEH_Param.Actuator.Cylinder.Length/2;
AEH_Param.Actuator.Rod.Length = 0.25+AEH_Param.Actuator.Cylinder.Length/2;
AEH_Param.Actuator.Rod.Radius = 0.025;

AEH_Param.Airfoil.Wing_Actuator_Base_Offset = [AEH_Param.Actuator.Cylinder.Length+AEH_Param.Actuator.Rod.Length-AEH_Param.Actuator.Initial_Overlap 0.1 0];

AEH_Param.Motor.R = 0.24;   % Ohm
AEH_Param.Motor.L = 1e-3;   % H
AEH_Param.Motor.K = 0.0637; % V/(rad/s)
AEH_Param.Motor.I = 5e-4;   % kg*m^2
AEH_Param.Motor.B = 5e-08;   % N*m/(rad/s)

AEH_Param.Control.OpAmp.Gain = 1000;
AEH_Param.Control.OpAmp.Rin = 1e6;
AEH_Param.Control.OpAmp.Rout = 100;
AEH_Param.Control.OpAmp.Vmin = -5;
AEH_Param.Control.OpAmp.Vmax = 5;
AEH_Param.Control.OpAmp.Vdotmax = 1000;
AEH_Param.Control.OpAmp.Bandwidth = 1e2;
AEH_Param.Control.OpAmp.V0 = 0;


%{
Inner_Cylinder_Length = 0.25;
Outer_Cylinder_Length = 0.35;
%}

% INITIAL CONTROLLER PARAMETER VALUES
Kp = 0.3;
Ki = 0.3;

% Actuator_Wing_Pt = [-0.5 0 0];  
