load FC01_All_On;
load FC02_DC_Tests;
load FC03_TRU_Test;
load FC04_Lamp_Test;
load FC05_ACPump_Test;
load FC06_Test;
load FC07_Test;
load FC08_Test;

Flight_Cycle_Num = 1;
