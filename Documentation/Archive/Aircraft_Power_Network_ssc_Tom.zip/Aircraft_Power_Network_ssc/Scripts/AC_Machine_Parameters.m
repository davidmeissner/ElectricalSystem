% Parameters for AC electric machines


%% Synchronous generator parameters

SRated = 50e3;  % V*A, rated apparent power
VRated = 200;   % V,   rated voltage, line-to-line, rms
fRated = 400;   % Hz,  rated frequency
NPP    = 2;     % number of pole pairs
EfdNom = 200;   % V, nominal field voltage
RpmNom = 60*fRated/NPP;  % rpm, nominal rotor speed

Rspu  = 0.08;   % p.u. stator resistance
Llspu = 0.072;  % p.u. stator leakage inductance
Lmdpu = 1.8;    % p.u. stator d-axis mutual inductance
Lmqpu = 1.76;   % p.u. stator q-axis mutual inductance

Rfdpu   = 0.06; % p.u. rotor field resistance
Llfdpu  = 0.18; % p.u. rotor field inductance
Rkdpu   = 0.16; % p.u. rotor d-axis damping winding resistance
Llkdpu  = 0.12; % p.u. rotor d-axis damping winding inductance
Rkq1pu  = 0.01; % p.u. rotor q-axis damping winding1 resistance
Llkq1pu = 0.96; % p.u. rotor q-axis damping winding1 inductance
Rkq2pu  = 0.12; % p.u. rotor q-axis damping winding2 resistance
Llkq2pu = 0.14; % p.u. rotor q-axis damping winding2 inductance

H   = 0.35;  % second, inertial constant
Dpu = 0.025; % p.u. damping coefficient

% generator base values
Ssbase = SRated;
Vsbase = VRated/sqrt(3)*sqrt(2);
Isbase = Ssbase/(1.5*Vsbase);
Zsbase = Vsbase/Isbase;
wbase  = 2*pi*fRated;
Lsbase = Zsbase/wbase;
Tbase  = Ssbase/(wbase/NPP);
Dbase  = Tbase/(wbase/NPP);


%% Induction motor parameters

SmRated = 12e3;  % V*A, rated apparent power
VmRated = 200;   % V,   rated voltage, line-to-line, rms
fmRated = 400;   % Hz,  rated frequency
NPPm    = 8;     % number of pole pairs

Rms  = 0.2761;    % ohm, stator resistance
Lmls = 2.191e-4;  % H, stator leakage inductance
Rmr  = 0.16;      % ohm, referred rotor resistance
Lmlr = 2.191e-4;  % H, referred rotor leakage inductance
Lmm  = 0.07614;   % H, magnetizing inductance
Jm   = 0.01;      % kg*m^2, moment of inertial
Dm   = 0;         % N*m/(rad/s), damping coefficient

% general base values
Smbase = SmRated;
wmbase = 2*pi*fmRated;
Tmbase = Smbase/(wmbase/NPPm);
Dmbase = Tmbase/(wmbase/NPPm);

% other base values (Delta)
VmbaseD = VmRated*sqrt(2);  % base voltage, line-to-line, peak value
ImbaseD = Smbase/(1.5*VmbaseD);
ZmbaseD = VmbaseD/ImbaseD;
LmbaseD = ZmbaseD/wmbase;

% parameters in p.u. (Delta)
RmspuD  = Rms/ZmbaseD;
LmlspuD = Lmls/LmbaseD;
RmrpuD  = Rmr/ZmbaseD;
LmlrpuD = Lmlr/LmbaseD;
LmmpuD  = Lmm/LmbaseD;

Hm   = 0.5*Jm*(wmbase/NPPm)/Tmbase;  % s, inertial constant
Dmpu = Dm/Dmbase;



