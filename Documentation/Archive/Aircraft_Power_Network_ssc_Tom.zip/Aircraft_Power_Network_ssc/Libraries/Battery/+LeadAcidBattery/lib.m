function lib( libInfo )
% Customize library

% Copyright 2008-2012 The MathWorks, Inc.
libInfo.Annotation = sprintf('Library of components used by the lead-acid\nbattery example, ssc_lead_acid_battery');
end
