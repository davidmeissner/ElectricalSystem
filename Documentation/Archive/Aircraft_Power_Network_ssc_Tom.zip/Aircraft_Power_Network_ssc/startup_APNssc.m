clear;
clc;

% Add paths
APNssc_HomeDir = pwd;
addpath(APNssc_HomeDir);
addpath([APNssc_HomeDir '/Images']);
addpath([APNssc_HomeDir '/Scripts']);
addpath([APNssc_HomeDir '/Libraries']);
addpath([APNssc_HomeDir '/Libraries/Battery']);
addpath([APNssc_HomeDir '/FC_Data']);

% Build battery library
if(exist('Libraries/Battery')==7)
    cd('Libraries/Battery');
    if((exist('+LeadAcidBattery')==7) && ~exist('./LeadAcidBattery_lib'))
        ssc_build LeadAcidBattery
    end
    cd(APNssc_HomeDir)
end

% Load parameters
APN_Model_PARAM;
load_FC_Data;
Ts = 1e-5;                  % sample time
AC_Machine_Parameters;      % synchronous and asynchronous machine parameters
Aileron_PARAM;              % aileron parameters
ssc_lead_acid_battery_ini;  % battery parameters

% Open model
%Aircraft_Power_Network_ssc
